

X = 5

def do():
  pass

print(X)